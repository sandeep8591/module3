package com.cg.Dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import com.cg.entity.Trainee;


@Repository
public class RestDaoImpl implements RestDao {
	
@PersistenceContext
EntityManager entityManager;

@Override
public void add(Trainee trainee) {
	// TODO Auto-generated method stub
	entityManager.persist(trainee);
	entityManager.flush();
}

@Override
public Trainee find(int traineeId) {
	return entityManager.find(Trainee.class, traineeId);
}

@Override
public Trainee delete(Trainee trainee) {
	Trainee trainee1=entityManager.find(Trainee.class, trainee.getTraineeId());
	if(trainee1!=null) {
		entityManager.remove(trainee1);
	System.out.println(trainee);
	return trainee;
	}
else{
		return null;
}
}

@Override
public List<Trainee> retrieveAll() {
	TypedQuery<Trainee> query=entityManager.createQuery("Select t from Trainee t",Trainee.class);
		return query.getResultList();
}

@Override
public Trainee update(Trainee trainee, int traineeId) {
	 Trainee t1=entityManager.find(Trainee.class, traineeId);
	 if(t1!=null) {
		 entityManager.remove(t1);
		 System.out.println(trainee);
		 trainee.setTraineeId(traineeId);;
		 entityManager.merge(trainee);
		 return trainee;
	 }
	 return null;
}
}

