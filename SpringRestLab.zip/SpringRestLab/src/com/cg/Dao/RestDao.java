package com.cg.Dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.entity.Trainee;
@Repository
public interface RestDao {
	public void add(Trainee trainee);

	public Trainee find(int traineeId);

	public Trainee delete(Trainee trainee);

	public List<Trainee> retrieveAll();

	public Trainee update(Trainee trainee,int traineeId);
}
