package com.cg.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.entity.Trainee;
import com.cg.service.RestService;



@RestController
public class SpringRestController {
	
@Autowired
RestService traineeService;

@RequestMapping(value ="/trainee/add/{traineeName}/{location}/{domain}",
method = RequestMethod.GET, headers="Accept=application/json")

public Trainee addTrainee(@PathVariable String traineeName,

@PathVariable String location,@PathVariable String domain) {

Trainee trainee=new Trainee();
trainee.setTraineeName(traineeName);
trainee.setLocation(location);
trainee.setDomain(domain);
traineeService.add(trainee);
return trainee;
}

@RequestMapping(value="/trainee/search/{traineeId}",method=RequestMethod.GET,headers="Accept=application/json")

public Trainee findTrainee(@PathVariable int traineeId) {
	Trainee trainee=traineeService.find(traineeId);
return trainee;
}

@RequestMapping(value="/trainee/delete/{traineeId}",method=RequestMethod.GET,headers="Accept=application/json")

public Trainee deleteTrainee(@PathVariable int traineeId) {

Trainee trainee=new Trainee();

trainee=traineeService.find(traineeId);

return traineeService.delete(trainee);

}

@RequestMapping(value="/trainees",method=RequestMethod.GET,headers="Accept=application/json")
public List<Trainee> allTrainees() {
return traineeService.retrieveAll();
}

@RequestMapping(value = "/trainees/update/{traineeId}/{traineeName}/{location}/{domain}",
 method = RequestMethod.GET, headers="Accept=application/json")
public Trainee updateTrainee(@PathVariable int traineeId,@PathVariable String traineeName,
@PathVariable String location,@PathVariable String domain) {
	Trainee trainee=new Trainee();
	trainee.setTraineeName(traineeName);
	trainee.setLocation(location);
	trainee.setDomain(domain);
	return traineeService.update(trainee,traineeId);
}
}