package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.Dao.RestDao;
import com.cg.entity.Trainee;
@Service
@Transactional
public class RestServiceImpl implements RestService{
	
@Autowired
	private RestDao rd;

@Override
public void add(Trainee trainee) {
	rd.add(trainee);
	
}

@Override
public Trainee find(int traineeId) {
	return rd.find(traineeId);
}

@Override
public Trainee delete(Trainee trainee) {
	return rd.delete(trainee);
	}

@Override
public List<Trainee> retrieveAll() {
	return rd.retrieveAll();
}

@Override
public Trainee update(Trainee trainee, int traineeId) {
return rd.update(trainee, traineeId);
}
}
	