package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Trainee;
@Service
@Transactional
public interface RestService {
public void add(Trainee trainee);

public Trainee find(int traineeId);

public Trainee delete(Trainee trainee);

public List<Trainee> retrieveAll();

public Trainee update(Trainee trainee,int traineeId);
}
