package com.cg.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.bean.Employee;


/**
 * @author anraipur 
 * 
 * EmployeeRepository interface extending CrudRepository
 *
 */

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, Long> {

}
