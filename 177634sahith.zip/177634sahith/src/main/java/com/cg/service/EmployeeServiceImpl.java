package com.cg.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Employee;
import com.cg.dao.EmployeeRepository;


/**
 * @author anraipur 
 * 
 * Implementation of EmployeeService interface
 *
 */

@Service
public class EmployeeServiceImpl implements EmployeeService{

	/**
	 * employeeRepository is dependency of EmployeeServiceImpl
	 */
	
	@Autowired
	private EmployeeRepository employeeRepository;

	/**
	 * Method Name: getAll()
	 * Return type: List<Employee>
	 * Parameters: NA
	 * Description: to get all the employee records
	 *
	 */
	
	public List<Employee> getAll() {
		List<Employee> list = new ArrayList<>();
		employeeRepository.findAll().forEach(list::add);
		return list;
	}

	/**
	 * Method Name: getEmployee()
	 * Return type: Optional<Employee>
	 * Parameters: long
	 * Description: search for the employee by id
	 *
	 */
	
	public Optional<Employee> getEmployee(long id) {
		return employeeRepository.findById(id);
	}

	
	/**
	 * Method Name: addEmployee()
	 * Return type: Employee
	 * Parameters: Employee
	 * Description: to add one employee record
	 *
	 */
	
	public Employee addEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}
	
	/**
	 * Method Name: updateEmp()
	 * Return type: Employee
	 * Parameters: Employee
	 * Description: to update one employee record
	 *
	 */

	public Employee updateEmp(Employee employee) {
		return employeeRepository.save(employee);
	}

	/**
	 * Method Name: deleteEmp()
	 * Return type: void
	 * Parameters: Long
	 * Description: to delete one employee record by id
	 *
	 */
	
	public void deleteEmp(Long id) {
		employeeRepository.deleteById(id);
	}

	/**
	 * Method Name: saveEmployees()
	 * Return type: Iterable<Employee>
	 * Parameters: List<Employee>
	 * Description: to save multiple records
	 *
	 */
	
	public Iterable<Employee> saveEmployees(List<Employee> employees) {


			return employeeRepository.saveAll(employees);
	}
}
