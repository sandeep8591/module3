/**
 * 
 */
package com.cg.service;

import java.util.List;
import java.util.Optional;

import com.cg.bean.Employee;

/**
 * @author anraipur 
 * 
 * Employee Service interface, provides methods for employee crud operations
 *
 */
public interface EmployeeService {

	public List<Employee> getAll();
	public Optional<Employee> getEmployee(long id);
	public Employee addEmployee(Employee employee);
	public Employee updateEmp(Employee employee);
	public void deleteEmp(Long id);
	public Iterable<Employee> saveEmployees(List<Employee> employees);
}
