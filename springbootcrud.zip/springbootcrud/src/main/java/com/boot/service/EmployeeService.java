package com.boot.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.dao.EmployeeRepository;
import com.boot.entity.Employee;

@Service
public class EmployeeService {

	//employeeRepository is dependency of EmployeeService
	
	@Autowired
	private EmployeeRepository employeeRepository;

	/*
	 * private List<Employee> listOfEmployee = new ArrayList<>(Arrays.asList(new
	 * Employee("sai", "mukesh", "sai@gl.com"), new Employee("Samba", "Murthi",
	 * "samba@gl.com"), new Employee("Android", "Sandeep", "sandeep@android.com"),
	 * new Employee("Shiva", "Reddy", "shiva@gl.com"), new Employee("bablu",
	 * "bambchik", "bablu@gl.com")));
	 */
	public List<Employee> getAll() {
		List<Employee> list = new ArrayList<>();
		employeeRepository.findAll().forEach(list::add);
		return list;
	}

	public Optional<Employee> getEmployee(String firstname) {
//		return listOfEmployee.stream().filter(s -> s.getFirstname().equals(firstname)).findFirst().get();
		return employeeRepository.findById(firstname);
	}

	public Employee addEmployee(Employee employee) {
//		listOfEmployee.add(employee);
		return employeeRepository.save(employee);
	}

	public Employee updateEmp(Employee employee, String firstname) {
		/*
		 * for (int i = 0; i < listOfEmployee.size(); i++) { if
		 * (listOfEmployee.get(i).getFirstname().equals(firstname)) {
		 * listOfEmployee.set(i, employee); } }
		 */
//		employeeRepository.saveByFirstname(employee);

		return employeeRepository.save(employee);
		
	}

	public void deleteEmp(String firstname) {
//		for (int i = 0; i < listOfEmployee.size(); i++) {
//			if (listOfEmployee.get(i).getFirstname().equals(firstname))
//				listOfEmployee.remove(i);
//		}
		employeeRepository.deleteById(firstname);
	}
}
